"""Iteration assembly executor."""
