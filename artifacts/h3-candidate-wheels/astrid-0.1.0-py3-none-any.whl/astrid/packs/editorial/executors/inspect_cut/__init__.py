"""Inspect cut executor package."""

from .run import main

__all__ = ["main"]
