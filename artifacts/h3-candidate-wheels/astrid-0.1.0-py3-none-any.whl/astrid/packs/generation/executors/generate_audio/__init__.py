"""Generate audio executor package."""
