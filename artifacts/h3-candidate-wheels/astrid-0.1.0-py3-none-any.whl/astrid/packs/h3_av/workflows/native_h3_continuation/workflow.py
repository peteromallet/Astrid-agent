# vibecomfy: generated
# For hand-editing, run: python -m vibecomfy.cli copy-to-recipe <id>
# vibecomfy: surface=canonical
"""Auto-generated ready_template — use python -m vibecomfy.cli copy-to-recipe <id> for hand-editing."""
from __future__ import annotations

from vibecomfy.templates import InputSpec, ModelAsset, OutputSpec, ReadyMetadata, new_workflow, node as raw_call, ref
from vibecomfy.workflow import VibeWorkflow
from vibecomfy.nodes.core import BasicGuider, BasicScheduler, CLIPLoader, ComfyMathExpression, KSamplerSelect, LoadAudio, LoadImage, LoraLoaderModelOnly, PreviewAny, RandomNoise, ResolutionSelector, SamplerCustomAdvanced, UNETLoader, VAEDecode, VAEDecodeAudio, VAELoader
from vibecomfy.nodes.videohelpersuite import VHS_LoadVideoFFmpeg, VHS_VideoCombine


AUDIO_VAE_NAME = 'minimax_h3_audio_vae_fp32.safetensors'
CLIP_NAME = 'qwen3vl_32b_minimax_h3_int8_convrot.safetensors'
DEFAULT_PROMPT = "End state: Morpheus remains in the same close/medium shot, seated in the red chair in the dark room, wearing the black coat, with the same camera position, lighting, identity, and acoustic perspective. In the generated continuation, he begins by saying the exact line: \"This is your last chance.\" He then continues with the exact line: \"You can poo or pee on my face.\" Preserve the supplied audiovisual prefix, including Morpheus's original voice, cadence, room tone, and timing, then carry that voice and acoustic perspective into both requested lines. Keep his expression calm and deliberate, looking forward with one hand resting in a restrained natural gesture. No camera change, reset, new character, subtitles, or visible text."
DEFAULT_PROMPT_2 = 'Create the opening clip for a new continuous video. Establish coherent subject identity, camera, lighting, environment, motion, voice, ambience, and audiovisual timing so later masked extensions can continue seamlessly. If an H3 keyframe is enabled at frame 1, treat it as the exact opening image and animate naturally forward. Connected reference images are identity/appearance references only and should not force their pose, framing, expression, or lighting onto the shot.'
DEFAULT_PROMPT_3 = 'Regenerate the complete soundtrack for the supplied source video. The entire visual stream is protected and authoritative: do not change, reinterpret, restart, or replace the video. Generate synchronized audio for the full clip from beginning to end, including dialogue/voice when visually implied, foley, impacts, movement sounds, room tone, ambience, and other scene-appropriate sound. Match visible timing precisely and maintain continuous acoustic perspective across the whole source clip.'
DEFAULT_SEED = 123456789
DEFAULT_SEED_2 = 123469134
DEFAULT_SEED_3 = 123481479
DEFAULT_SEED_4 = 123493824
DEFAULT_SEED_5 = 123506169
DEFAULT_SEED_6 = 123518514
DEFAULT_SEED_7 = 123432109
DEFAULT_SEED_8 = 918273645
DISABLED = 'disabled'
EXISTING_VIDEO = 'Existing Video'
FIXED = 'fixed'
GUIDE_STRENGTH = 0.95
KEEP_SOURCE_AUDIO = 'Keep source audio'
LORA_NAME = 'minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors'
MATCH = 'match'
UNET_NAME = 'minimax_h3_ref2va_pruned_int8_convrot.safetensors'
VIDEO_H264_MP4 = 'video/h264-mp4'
VIDEO_VAE_NAME = 'minimax_h3_video_vae_int8_convrot.safetensors'
YUV420P = 'yuv420p'
DEFAULT_SOURCE_VIDEO = ''


MODELS = {
    'vae': ModelAsset(url='https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/vae/minimax_h3_audio_vae_fp32.safetensors', subdir='vae'),
    'lora': ModelAsset(url='https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/loras/minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors', subdir='loras'),
    'diffusion_model': ModelAsset(url='https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/diffusion_models/minimax_h3_ref2va_pruned_int8_convrot.safetensors', subdir='diffusion_models'),
    'vae_2': ModelAsset(url='https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/vae/minimax_h3_video_vae_int8_convrot.safetensors', subdir='vae'),
    'text_encoder': ModelAsset(url='https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/text_encoders/qwen3vl_32b_minimax_h3_int8_convrot.safetensors', subdir='text_encoders'),
}


PUBLIC_INPUT_METADATA = {
    'model': InputSpec(node=ref('unetloader'), field='unet_name', default=None, infer_type=False),
    'seed': InputSpec(node=ref('randomnoise_2'), field='noise_seed', default=None, infer_type=False),
    'steps': InputSpec(node=ref('basicscheduler'), field='steps', default=None, infer_type=False),
    'source_video': InputSpec(node=ref('vhs_loadvideoffmpeg'), field='video', default=DEFAULT_SOURCE_VIDEO, type='CHOICE', media_semantics='video', infer_type=False),
}


READY_METADATA = ReadyMetadata.build(
    capability='video',
    template_id='source',
    inputs=PUBLIC_INPUT_METADATA,
    models=MODELS,
    requirements={'missing_nodes': ['MiniMaxH3AVExtensionController', 'MiniMaxH3AVSourceAudioModeParam', 'MiniMaxH3AVStartModeParam', 'MiniMaxH3AudioVAECompatibility', 'MiniMaxH3CropTo32', 'MiniMaxH3CustomKeyframes', 'MiniMaxH3FinalizeVHSOutput', 'MiniMaxH3GeneratedAVMaskedContext', 'MiniMaxH3LastActiveVHSPreviewBarrier', 'MiniMaxH3SourceAudioPolicy', 'MiniMaxH3SourceAudioRegenLength', 'MiniMaxH3SourceAudioRegenMask', 'MiniMaxH3StartCanvasSelector', 'MiniMaxH3StartMaskedContext', 'MiniMaxH3StreamLiveExtensionAVToVHS', 'MiniMaxH3Validate24FPSVideo', 'Note'], 'runtime': {'comfy_commit': 'ee71d5c4993f29086b27fde1629a945ae48425bf', 'comfy_version': '==0.36.0', 'packages': {'comfy-aimdo': '==0.5.3', 'comfy-kitchen': '==0.2.34', 'torch': '==2.10.0+cu130'}, 'launch_flags': ['--use-ck-attention', '--disable-comfy-compiler']}},
    custom_node_packs={'ComfyUI-H3-Motion-Context-MultiRef': {'commit': '361624fb406b63eb6694442eac6c895fc1533a70', 'url': 'https://github.com/seitanism/ComfyUI-H3-Motion-Context-MultiRef.git', 'classes_used': ['MiniMaxH3AVExtensionController', 'MiniMaxH3AVSourceAudioModeParam', 'MiniMaxH3AVStartModeParam', 'MiniMaxH3AudioVAECompatibility', 'MiniMaxH3CropTo32', 'MiniMaxH3CustomKeyframes', 'MiniMaxH3FinalizeVHSOutput', 'MiniMaxH3GeneratedAVMaskedContext', 'MiniMaxH3LastActiveVHSPreviewBarrier', 'MiniMaxH3ReferenceToVideo', 'MiniMaxH3SigmaShift', 'MiniMaxH3SourceAudioPolicy', 'MiniMaxH3SourceAudioRegenLength', 'MiniMaxH3SourceAudioRegenMask', 'MiniMaxH3StartCanvasSelector', 'MiniMaxH3StartMaskedContext', 'MiniMaxH3StreamLiveExtensionAVToVHS', 'MiniMaxH3Validate24FPSVideo'], 'pip_packages': ['safetensors'], 'status': 'discovered'}, 'ComfyUI-VideoHelperSuite': {'commit': '4ee72c065db22c9d96c2427954dc69e7b908444b', 'url': 'https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite.git', 'class_schema_sha256': '8391e679554eecd5d324a3e34a713ff240e619e3a07476587845ba18c9fae310', 'classes_used': ['VHS_LoadVideoFFmpeg', 'VHS_VideoCombine'], 'pip_packages': [], 'status': 'discovered'}},
    operation='imported',
    origin_kind='agent-edit',
    artifact_class='open_draft',
    execution_ready=False,
    source_kind='raw_json',
    source_hash='sha256:87a85563ab868d4202a3f37f02e30d4749b865bcf8b050f55991a6c980ca9fa4',
    workflow_shape={'nodes': 102, 'runtime_nodes': 99, 'helper_nodes': 3, 'edges': 262, 'inputs': 2, 'outputs': 1},
    output_mode='scratchpad',
    source_type='api',
    source_ref='source.json',
    source_path='source.json',
    workflow_source_id='source',
    workflow_source_type='api',
    raw_workflow_shape='ui',
    source_provenance={'records': [{'node_id': '120', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '121', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '124', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '210', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '211', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '214', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '300', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '310', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '311', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '314', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '400', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '410', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '411', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '414', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '500', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '510', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '511', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '514', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '600', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '610', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '611', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '614', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '103', 'class_type': 'MiniMaxH3StartMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '201', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '301', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '401', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '501', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '601', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '4', 'class_type': 'VAELoader', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '3', 'class_type': 'VAELoader', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '2', 'class_type': 'CLIPLoader', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1', 'class_type': 'UNETLoader', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '970', 'class_type': 'LoadImage', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '977', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '200', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '937', 'class_type': 'KSamplerSelect', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '939', 'class_type': 'PrimitiveInt', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.31.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.31.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '940', 'class_type': 'PrimitiveInt', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.31.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.31.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '992', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '993', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '994', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '995', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '996', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '997', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '998', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '999', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1000', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1001', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '1002', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1003', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1004', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '1005', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1006', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1007', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '110', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '936', 'class_type': 'PrimitiveInt', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '975', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '974', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1008', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1009', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '991', 'class_type': 'VAEDecodeAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '990', 'class_type': 'VAEDecode', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '973', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1022', 'class_type': 'MiniMaxH3CustomKeyframes', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': '75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '946', 'class_type': 'MiniMaxH3StreamLiveExtensionAVToVHS', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'update8-modular-stream-inputs', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-modular-stream-inputs', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '99', 'class_type': 'VHS_LoadVideoFFmpeg', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '4ee72c065db22c9d96c2427954dc69e7b908444b', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:4ee72c065db22c9d96c2427954dc69e7b908444b', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '100', 'class_type': 'MiniMaxH3CropTo32', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1021', 'class_type': 'LoadImage', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1020', 'class_type': 'LoadImage', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '976', 'class_type': 'BasicScheduler', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '5', 'class_type': 'MiniMaxH3SigmaShift', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '935', 'class_type': 'LoraLoaderModelOnly', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '988', 'class_type': 'ModelAttentionBackend', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1010', 'class_type': 'VHS_VideoCombine', 'scope': 'top_level', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'ver': '1.7.7', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry'}, {'node_id': '900', 'class_type': 'Note', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': False, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'helper_ui'}, {'node_id': '972', 'class_type': 'MiniMaxH3StartCanvasSelector', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '101', 'class_type': 'PrimitiveFloat', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '980', 'class_type': 'MiniMaxH3AVExtensionController', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': '75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1025', 'class_type': 'Note', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': False, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'helper_ui'}, {'node_id': '1024', 'class_type': 'ResolutionSelector', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '102', 'class_type': 'ComfyMathExpression', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1026', 'class_type': 'PreviewAny', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': False, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'helper_ui'}, {'node_id': '1027', 'class_type': 'LoadAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1028', 'class_type': 'LoadAudio', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1029', 'class_type': 'Reroute', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': False, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'helper_ui'}, {'node_id': '1030', 'class_type': 'Reroute', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': False, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'helper_ui'}, {'node_id': '1031', 'class_type': 'MiniMaxH3SourceAudioRegenLength', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1032', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1033', 'class_type': 'MiniMaxH3SourceAudioRegenMask', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1034', 'class_type': 'RandomNoise', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1035', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1036', 'class_type': 'SamplerCustomAdvanced', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1037', 'class_type': 'MiniMaxH3SourceAudioPolicy', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1038', 'class_type': 'MiniMaxH3AVStartModeParam', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1039', 'class_type': 'PrimitiveInt', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1040', 'class_type': 'PrimitiveInt', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1041', 'class_type': 'MiniMaxH3AVSourceAudioModeParam', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1042', 'class_type': 'MiniMaxH3LastActiveVHSPreviewBarrier', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'update8-preview-barrier', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-preview-barrier', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1043', 'class_type': 'MiniMaxH3FinalizeVHSOutput', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'update8-bypass-safe-final-sink', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-bypass-safe-final-sink', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1044', 'class_type': 'Note', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': False, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'helper_ui'}, {'node_id': '1045', 'class_type': 'MiniMaxH3Validate24FPSVideo', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1046', 'class_type': 'MiniMaxH3AudioVAECompatibility', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}], 'requirements': [{'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version_pin': {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': '75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'node_ids': ('1022', '980'), 'class_types': ('MiniMaxH3AVExtensionController', 'MiniMaxH3CustomKeyframes')}, 'node_ids': ('1022', '980'), 'class_types': ('MiniMaxH3AVExtensionController', 'MiniMaxH3CustomKeyframes'), 'low_confidence': True}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version_pin': {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'node_ids': ('100', '103', '1031', '1033', '201', '301', '401', '501', '601', '972'), 'class_types': ('MiniMaxH3CropTo32', 'MiniMaxH3GeneratedAVMaskedContext', 'MiniMaxH3SourceAudioRegenLength', 'MiniMaxH3SourceAudioRegenMask', 'MiniMaxH3StartCanvasSelector', 'MiniMaxH3StartMaskedContext')}, 'node_ids': ('100', '103', '1031', '1033', '201', '301', '401', '501', '601', '972'), 'class_types': ('MiniMaxH3CropTo32', 'MiniMaxH3GeneratedAVMaskedContext', 'MiniMaxH3SourceAudioRegenLength', 'MiniMaxH3SourceAudioRegenMask', 'MiniMaxH3StartCanvasSelector', 'MiniMaxH3StartMaskedContext'), 'low_confidence': True}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-bypass-safe-final-sink', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version_pin': {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-bypass-safe-final-sink', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'update8-bypass-safe-final-sink', 'node_ids': ('1043',), 'class_types': ('MiniMaxH3FinalizeVHSOutput',)}, 'node_ids': ('1043',), 'class_types': ('MiniMaxH3FinalizeVHSOutput',), 'low_confidence': True}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-modular-stream-inputs', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version_pin': {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-modular-stream-inputs', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'update8-modular-stream-inputs', 'node_ids': ('946',), 'class_types': ('MiniMaxH3StreamLiveExtensionAVToVHS',)}, 'node_ids': ('946',), 'class_types': ('MiniMaxH3StreamLiveExtensionAVToVHS',), 'low_confidence': True}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-preview-barrier', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version_pin': {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-preview-barrier', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'update8-preview-barrier', 'node_ids': ('1042',), 'class_types': ('MiniMaxH3LastActiveVHSPreviewBarrier',)}, 'node_ids': ('1042',), 'class_types': ('MiniMaxH3LastActiveVHSPreviewBarrier',), 'low_confidence': True}, {'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core', 'cnr_id': 'comfy-core', 'aux_id': None, 'version_pin': {'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'version': '0.30.0', 'node_ids': ('1', '101', '102', '1027', '1028', '1032', '1039', '1040', '110', '120', '121', '124', '2', '200', '210', '211', '214', '3', '300', '310', '311', '314', '4', '400', '410', '411', '414', '5', '500', '510', '511', '514', '600', '610', '611', '614', '935', '936', '937', '970', '973'), 'class_types': ('BasicGuider', 'CLIPLoader', 'ComfyMathExpression', 'KSamplerSelect', 'LoadAudio', 'LoadImage', 'LoraLoaderModelOnly', 'MiniMaxH3ReferenceToVideo', 'MiniMaxH3SigmaShift', 'PrimitiveFloat', 'PrimitiveInt', 'RandomNoise', 'SamplerCustomAdvanced', 'UNETLoader', 'VAELoader')}, 'node_ids': ('1', '101', '102', '1027', '1028', '1032', '1039', '1040', '110', '120', '121', '124', '2', '200', '210', '211', '214', '3', '300', '310', '311', '314', '4', '400', '410', '411', '414', '5', '500', '510', '511', '514', '600', '610', '611', '614', '935', '936', '937', '970', '973'), 'class_types': ('BasicGuider', 'CLIPLoader', 'ComfyMathExpression', 'KSamplerSelect', 'LoadAudio', 'LoadImage', 'LoraLoaderModelOnly', 'MiniMaxH3ReferenceToVideo', 'MiniMaxH3SigmaShift', 'PrimitiveFloat', 'PrimitiveInt', 'RandomNoise', 'SamplerCustomAdvanced', 'UNETLoader', 'VAELoader'), 'low_confidence': False}, {'identity_key': 'cnr:comfy-core|aux:-|ver:0.31.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core', 'cnr_id': 'comfy-core', 'aux_id': None, 'version_pin': {'identity_key': 'cnr:comfy-core|aux:-|ver:0.31.0', 'locator_key': 'cnr:comfy-core|aux:-', 'version': '0.31.0', 'node_ids': ('939', '940'), 'class_types': ('PrimitiveInt',)}, 'node_ids': ('939', '940'), 'class_types': ('PrimitiveInt',), 'low_confidence': False}, {'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core', 'cnr_id': 'comfy-core', 'aux_id': None, 'version_pin': {'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'version': '0.33.0', 'node_ids': ('1000', '1002', '1003', '1005', '1006', '1008', '1009', '1020', '1021', '1024', '1034', '1035', '1036', '974', '975', '976', '977', '988', '990', '991', '993', '994', '996', '997', '999'), 'class_types': ('BasicGuider', 'BasicScheduler', 'LoadImage', 'ModelAttentionBackend', 'RandomNoise', 'ResolutionSelector', 'SamplerCustomAdvanced', 'VAEDecode', 'VAEDecodeAudio')}, 'node_ids': ('1000', '1002', '1003', '1005', '1006', '1008', '1009', '1020', '1021', '1024', '1034', '1035', '1036', '974', '975', '976', '977', '988', '990', '991', '993', '994', '996', '997', '999'), 'class_types': ('BasicGuider', 'BasicScheduler', 'LoadImage', 'ModelAttentionBackend', 'RandomNoise', 'ResolutionSelector', 'SamplerCustomAdvanced', 'VAEDecode', 'VAEDecodeAudio'), 'low_confidence': False}, {'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'version_pin': {'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'version': '1.7.7', 'node_ids': ('1001', '1004', '1007', '1010', '992', '995', '998'), 'class_types': ('VHS_VideoCombine',)}, 'node_ids': ('1001', '1004', '1007', '1010', '992', '995', '998'), 'class_types': ('VHS_VideoCombine',), 'low_confidence': False}, {'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:4ee72c065db22c9d96c2427954dc69e7b908444b', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'resolver_kind': 'registry', 'cnr_id': 'comfyui-videohelpersuite', 'aux_id': None, 'version_pin': {'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:4ee72c065db22c9d96c2427954dc69e7b908444b', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'version': '4ee72c065db22c9d96c2427954dc69e7b908444b', 'node_ids': ('99',), 'class_types': ('VHS_LoadVideoFFmpeg',)}, 'node_ids': ('99',), 'class_types': ('VHS_LoadVideoFFmpeg',), 'low_confidence': False}], 'warnings': [{'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3StartMaskedContext has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('103',), 'class_types': ('MiniMaxH3StartMaskedContext',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3GeneratedAVMaskedContext has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('201',), 'class_types': ('MiniMaxH3GeneratedAVMaskedContext',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3GeneratedAVMaskedContext has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('301',), 'class_types': ('MiniMaxH3GeneratedAVMaskedContext',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3GeneratedAVMaskedContext has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('401',), 'class_types': ('MiniMaxH3GeneratedAVMaskedContext',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3GeneratedAVMaskedContext has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('501',), 'class_types': ('MiniMaxH3GeneratedAVMaskedContext',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3GeneratedAVMaskedContext has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('601',), 'class_types': ('MiniMaxH3GeneratedAVMaskedContext',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3CustomKeyframes has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('1022',), 'class_types': ('MiniMaxH3CustomKeyframes',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3StreamLiveExtensionAVToVHS has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-modular-stream-inputs', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('946',), 'class_types': ('MiniMaxH3StreamLiveExtensionAVToVHS',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3CropTo32 has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('100',), 'class_types': ('MiniMaxH3CropTo32',), 'low_confidence': False}, {'code': 'helper_ui_node', 'message': 'Note is helper/UI-only and is excluded from execution provenance requirements', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('900',), 'class_types': ('Note',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3StartCanvasSelector has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('972',), 'class_types': ('MiniMaxH3StartCanvasSelector',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3AVExtensionController has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('980',), 'class_types': ('MiniMaxH3AVExtensionController',), 'low_confidence': False}, {'code': 'helper_ui_node', 'message': 'Note is helper/UI-only and is excluded from execution provenance requirements', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1025',), 'class_types': ('Note',), 'low_confidence': False}, {'code': 'helper_ui_node', 'message': 'PreviewAny is helper/UI-only and is excluded from execution provenance requirements', 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'node_ids': ('1026',), 'class_types': ('PreviewAny',), 'low_confidence': False}, {'code': 'helper_ui_node', 'message': 'Reroute is helper/UI-only and is excluded from execution provenance requirements', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1029',), 'class_types': ('Reroute',), 'low_confidence': False}, {'code': 'helper_ui_node', 'message': 'Reroute is helper/UI-only and is excluded from execution provenance requirements', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1030',), 'class_types': ('Reroute',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3SourceAudioRegenLength has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('1031',), 'class_types': ('MiniMaxH3SourceAudioRegenLength',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3SourceAudioRegenMask has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('1033',), 'class_types': ('MiniMaxH3SourceAudioRegenMask',), 'low_confidence': False}, {'code': 'unprovenanced_execution_node', 'message': 'MiniMaxH3SourceAudioPolicy has no cnr_id or aux_id provenance', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1037',), 'class_types': ('MiniMaxH3SourceAudioPolicy',), 'low_confidence': True}, {'code': 'unprovenanced_execution_node', 'message': 'MiniMaxH3AVStartModeParam has no cnr_id or aux_id provenance', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1038',), 'class_types': ('MiniMaxH3AVStartModeParam',), 'low_confidence': True}, {'code': 'unprovenanced_execution_node', 'message': 'MiniMaxH3AVSourceAudioModeParam has no cnr_id or aux_id provenance', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1041',), 'class_types': ('MiniMaxH3AVSourceAudioModeParam',), 'low_confidence': True}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3LastActiveVHSPreviewBarrier has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-preview-barrier', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('1042',), 'class_types': ('MiniMaxH3LastActiveVHSPreviewBarrier',), 'low_confidence': False}, {'code': 'aux_only_git_provenance', 'message': 'MiniMaxH3FinalizeVHSOutput has aux_id provenance without cnr_id', 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-bypass-safe-final-sink', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'node_ids': ('1043',), 'class_types': ('MiniMaxH3FinalizeVHSOutput',), 'low_confidence': False}, {'code': 'helper_ui_node', 'message': 'Note is helper/UI-only and is excluded from execution provenance requirements', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1044',), 'class_types': ('Note',), 'low_confidence': False}, {'code': 'unprovenanced_execution_node', 'message': 'MiniMaxH3Validate24FPSVideo has no cnr_id or aux_id provenance', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1045',), 'class_types': ('MiniMaxH3Validate24FPSVideo',), 'low_confidence': True}, {'code': 'unprovenanced_execution_node', 'message': 'MiniMaxH3AudioVAECompatibility has no cnr_id or aux_id provenance', 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'node_ids': ('1046',), 'class_types': ('MiniMaxH3AudioVAECompatibility',), 'low_confidence': True}], 'conflicts': [{'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('121',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('211',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('300',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('311',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('400',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('411',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('500',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('511',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('600',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('611',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('200',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('110',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.33.0',), 'node_ids': ('975',), 'class_types': ('BasicGuider',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('973',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3SigmaShift is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('5',), 'class_types': ('MiniMaxH3SigmaShift',)}, {'code': 'suspicious_comfy_core', 'message': "ModelAttentionBackend is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.33.0',), 'node_ids': ('988',), 'class_types': ('ModelAttentionBackend',)}, {'code': 'suspicious_comfy_core', 'message': "ResolutionSelector is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.33.0',), 'node_ids': ('1024',), 'class_types': ('ResolutionSelector',)}, {'code': 'suspicious_comfy_core', 'message': "MiniMaxH3ReferenceToVideo is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0',), 'node_ids': ('1032',), 'class_types': ('MiniMaxH3ReferenceToVideo',)}, {'code': 'suspicious_comfy_core', 'message': "BasicGuider is tagged with cnr_id='comfy-core' but is not a known core class", 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.33.0',), 'node_ids': ('1035',), 'class_types': ('BasicGuider',)}, {'code': 'conflicting_authored_versions', 'message': 'multiple authored versions declared for cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'versions': ('75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'update8-bypass-safe-final-sink', 'update8-modular-stream-inputs', 'update8-preview-barrier'), 'node_ids': ('100', '1022', '103', '1031', '1033', '1042', '1043', '201', '301', '401', '501', '601', '946', '972', '980'), 'class_types': ('MiniMaxH3AVExtensionController', 'MiniMaxH3CropTo32', 'MiniMaxH3CustomKeyframes', 'MiniMaxH3FinalizeVHSOutput', 'MiniMaxH3GeneratedAVMaskedContext', 'MiniMaxH3LastActiveVHSPreviewBarrier', 'MiniMaxH3SourceAudioRegenLength', 'MiniMaxH3SourceAudioRegenMask', 'MiniMaxH3StartCanvasSelector', 'MiniMaxH3StartMaskedContext', 'MiniMaxH3StreamLiveExtensionAVToVHS')}, {'code': 'conflicting_authored_versions', 'message': 'multiple authored versions declared for cnr:comfy-core|aux:-', 'locator_key': 'cnr:comfy-core|aux:-', 'versions': ('0.30.0', '0.31.0', '0.33.0'), 'node_ids': ('1', '1000', '1002', '1003', '1005', '1006', '1008', '1009', '101', '102', '1020', '1021', '1024', '1027', '1028', '1032', '1034', '1035', '1036', '1039', '1040', '110', '120', '121', '124', '2', '200', '210', '211', '214', '3', '300', '310', '311', '314', '4', '400', '410', '411', '414', '5', '500', '510', '511', '514', '600', '610', '611', '614', '935', '936', '937', '939', '940', '970', '973', '974', '975', '976', '977', '988', '990', '991', '993', '994', '996', '997', '999'), 'class_types': ('BasicGuider', 'BasicScheduler', 'CLIPLoader', 'ComfyMathExpression', 'KSamplerSelect', 'LoadAudio', 'LoadImage', 'LoraLoaderModelOnly', 'MiniMaxH3ReferenceToVideo', 'MiniMaxH3SigmaShift', 'ModelAttentionBackend', 'PrimitiveFloat', 'PrimitiveInt', 'RandomNoise', 'ResolutionSelector', 'SamplerCustomAdvanced', 'UNETLoader', 'VAEDecode', 'VAEDecodeAudio', 'VAELoader')}, {'code': 'conflicting_authored_versions', 'message': 'multiple authored versions declared for cnr:comfyui-videohelpersuite|aux:-', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'versions': ('1.7.7', '4ee72c065db22c9d96c2427954dc69e7b908444b'), 'node_ids': ('1001', '1004', '1007', '1010', '99', '992', '995', '998'), 'class_types': ('VHS_LoadVideoFFmpeg', 'VHS_VideoCombine')}], 'version_pins': [{'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': '75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'node_ids': ('1022', '980'), 'class_types': ('MiniMaxH3AVExtensionController', 'MiniMaxH3CustomKeyframes')}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'node_ids': ('100', '103', '1031', '1033', '201', '301', '401', '501', '601', '972'), 'class_types': ('MiniMaxH3CropTo32', 'MiniMaxH3GeneratedAVMaskedContext', 'MiniMaxH3SourceAudioRegenLength', 'MiniMaxH3SourceAudioRegenMask', 'MiniMaxH3StartCanvasSelector', 'MiniMaxH3StartMaskedContext')}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-bypass-safe-final-sink', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'update8-bypass-safe-final-sink', 'node_ids': ('1043',), 'class_types': ('MiniMaxH3FinalizeVHSOutput',)}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-modular-stream-inputs', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'update8-modular-stream-inputs', 'node_ids': ('946',), 'class_types': ('MiniMaxH3StreamLiveExtensionAVToVHS',)}, {'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-preview-barrier', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'version': 'update8-preview-barrier', 'node_ids': ('1042',), 'class_types': ('MiniMaxH3LastActiveVHSPreviewBarrier',)}, {'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'version': '0.30.0', 'node_ids': ('1', '101', '102', '1027', '1028', '1032', '1039', '1040', '110', '120', '121', '124', '2', '200', '210', '211', '214', '3', '300', '310', '311', '314', '4', '400', '410', '411', '414', '5', '500', '510', '511', '514', '600', '610', '611', '614', '935', '936', '937', '970', '973'), 'class_types': ('BasicGuider', 'CLIPLoader', 'ComfyMathExpression', 'KSamplerSelect', 'LoadAudio', 'LoadImage', 'LoraLoaderModelOnly', 'MiniMaxH3ReferenceToVideo', 'MiniMaxH3SigmaShift', 'PrimitiveFloat', 'PrimitiveInt', 'RandomNoise', 'SamplerCustomAdvanced', 'UNETLoader', 'VAELoader')}, {'identity_key': 'cnr:comfy-core|aux:-|ver:0.31.0', 'locator_key': 'cnr:comfy-core|aux:-', 'version': '0.31.0', 'node_ids': ('939', '940'), 'class_types': ('PrimitiveInt',)}, {'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'version': '0.33.0', 'node_ids': ('1000', '1002', '1003', '1005', '1006', '1008', '1009', '1020', '1021', '1024', '1034', '1035', '1036', '974', '975', '976', '977', '988', '990', '991', '993', '994', '996', '997', '999'), 'class_types': ('BasicGuider', 'BasicScheduler', 'LoadImage', 'ModelAttentionBackend', 'RandomNoise', 'ResolutionSelector', 'SamplerCustomAdvanced', 'VAEDecode', 'VAEDecodeAudio')}, {'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:1.7.7', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'version': '1.7.7', 'node_ids': ('1001', '1004', '1007', '1010', '992', '995', '998'), 'class_types': ('VHS_VideoCombine',)}, {'identity_key': 'cnr:comfyui-videohelpersuite|aux:-|ver:4ee72c065db22c9d96c2427954dc69e7b908444b', 'locator_key': 'cnr:comfyui-videohelpersuite|aux:-', 'version': '4ee72c065db22c9d96c2427954dc69e7b908444b', 'node_ids': ('99',), 'class_types': ('VHS_LoadVideoFFmpeg',)}], 'required_pack_slugs': ['comfy-core', 'comfyui-videohelpersuite'], 'aux_only': [{'node_id': '103', 'class_type': 'MiniMaxH3StartMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '201', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '301', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '401', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '501', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '601', 'class_type': 'MiniMaxH3GeneratedAVMaskedContext', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1022', 'class_type': 'MiniMaxH3CustomKeyframes', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': '75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '946', 'class_type': 'MiniMaxH3StreamLiveExtensionAVToVHS', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'update8-modular-stream-inputs', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-modular-stream-inputs', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '100', 'class_type': 'MiniMaxH3CropTo32', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '972', 'class_type': 'MiniMaxH3StartCanvasSelector', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '980', 'class_type': 'MiniMaxH3AVExtensionController', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': '75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:75432bdb14d7ec02c8f0d8932bdc78b4afed603b', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1031', 'class_type': 'MiniMaxH3SourceAudioRegenLength', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1033', 'class_type': 'MiniMaxH3SourceAudioRegenMask', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:ee38f3dd3bcdbab3cfecb8c7e60a3e20a41e5277', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1042', 'class_type': 'MiniMaxH3LastActiveVHSPreviewBarrier', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'update8-preview-barrier', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-preview-barrier', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}, {'node_id': '1043', 'class_type': 'MiniMaxH3FinalizeVHSOutput', 'scope': 'top_level', 'cnr_id': None, 'aux_id': 'seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'ver': 'update8-bypass-safe-final-sink', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef|ver:update8-bypass-safe-final-sink', 'locator_key': 'cnr:-|aux:seitanism/ComfyUI-H3-Motion-Context-MultiRef', 'resolver_kind': 'aux_git'}], 'unprovenanced': [{'node_id': '1037', 'class_type': 'MiniMaxH3SourceAudioPolicy', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1038', 'class_type': 'MiniMaxH3AVStartModeParam', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1041', 'class_type': 'MiniMaxH3AVSourceAudioModeParam', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1045', 'class_type': 'MiniMaxH3Validate24FPSVideo', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}, {'node_id': '1046', 'class_type': 'MiniMaxH3AudioVAECompatibility', 'scope': 'top_level', 'cnr_id': None, 'aux_id': None, 'ver': None, 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:-|aux:-|ver:-', 'locator_key': 'cnr:-|aux:-', 'resolver_kind': 'unprovenanced'}], 'core_slug_non_core': [{'node_id': '121', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '211', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '300', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '311', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '400', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '411', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '500', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '511', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '600', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '611', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '200', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '110', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '975', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '973', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '5', 'class_type': 'MiniMaxH3SigmaShift', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '988', 'class_type': 'ModelAttentionBackend', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1024', 'class_type': 'ResolutionSelector', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1032', 'class_type': 'MiniMaxH3ReferenceToVideo', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.30.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.30.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}, {'node_id': '1035', 'class_type': 'BasicGuider', 'scope': 'top_level', 'cnr_id': 'comfy-core', 'aux_id': None, 'ver': '0.33.0', 'subgraph_id': None, 'subgraph_index': None, 'execution_looking': True, 'identity_key': 'cnr:comfy-core|aux:-|ver:0.33.0', 'locator_key': 'cnr:comfy-core|aux:-', 'resolver_kind': 'comfy_core'}], 'low_confidence': True},
    source_id='source',
    source_workflow_path='source.json',
    provenance={'operation': 'captured', 'artifact_class': 'execution_ready_candidate', 'execution_ready': True, 'origin_kind': 'agent-edit'},
    source_bundle={'format_version': 2, 'generation_id': 'db356ac35a3896cc6396bd50c9a16faaf4036d337feeb7f0251a98e86dceb590', 'custody_digest': 'a038e5b4152f727c3b314b9f2544e145b8b145c712d8ed55efe9113bd5dd73a4'},
)

def build(*, model=UNET_NAME, steps=8, seed=DEFAULT_SEED, prompt=DEFAULT_PROMPT,
          duration=5, source_video='', source_start=0, source_frames=0) -> VibeWorkflow:
    """Build the workflow (auto-generated)."""
    with new_workflow(READY_METADATA, source_path=__file__) as wf:

        # Loaders
        unetloader = UNETLoader(unet_name=UNET_NAME, weight_dtype='default')
        cliploader = CLIPLoader(clip_name=CLIP_NAME, type='minimax', device='default')
        vaeloader = VAELoader(vae_name=VIDEO_VAE_NAME)
        vaeloader_2 = VAELoader(vae_name=AUDIO_VAE_NAME)

        vhs_loadvideoffmpeg = VHS_LoadVideoFFmpeg(
            # H3's source-context tensors must fit alongside the 32 GB-class
            # sampler.  The source asset is 4K, but this extension template
            # intentionally generates at 0.5 MP; decode the speaking prefix at
            # that working resolution instead of retaining a 4K context.
            custom_height=576,
            custom_width=1024,
            force_rate=24,
            format='AnimateDiff',
            frame_load_cap=0,
            start_time=0,
            video=DEFAULT_SOURCE_VIDEO,
            videopreview={'hidden': False, 'paused': False, 'params': {}, 'muted': False},
        )

        comfymathexpression = ComfyMathExpression(
            expression='max(5, round(a * 24)) + (5 - (max(5, round(a * 24)) % 17)) % 17',
            **{'values.a': 5},
        )

        randomnoise_2 = RandomNoise(
            noise_seed=DEFAULT_SEED,
            control_after_generate=FIXED,
        )

        randomnoise_3 = RandomNoise(
            noise_seed=DEFAULT_SEED_2,
            control_after_generate=FIXED,
            _mode=4,
        )

        randomnoise_4 = RandomNoise(
            noise_seed=DEFAULT_SEED_3,
            control_after_generate=FIXED,
            _mode=4,
        )

        randomnoise_5 = RandomNoise(
            noise_seed=DEFAULT_SEED_4,
            control_after_generate=FIXED,
            _mode=4,
        )

        randomnoise_6 = RandomNoise(
            noise_seed=DEFAULT_SEED_5,
            control_after_generate=FIXED,
            _mode=4,
        )

        randomnoise_7 = RandomNoise(
            noise_seed=DEFAULT_SEED_6,
            control_after_generate=FIXED,
            _mode=4,
        )

        # Sampling
        ksamplerselect = KSamplerSelect(sampler_name='res_multistep')

        # Inputs
        loadimage_3 = LoadImage(image='', _mode=4)

        randomnoise_8 = RandomNoise(
            noise_seed=DEFAULT_SEED_7,
            control_after_generate=FIXED,
            _mode=4,
        )

        minimaxh3avextensioncontroller = raw_call('MiniMaxH3AVExtensionController',
            _outputs=('start_mode', 'active_extensions', 'audio_feather_ticks', 'preview_mode', 'source_audio_mode'),
            active_extensions=1,
            audio_feather_ticks=8,
            previews='All Active',
            source_audio=KEEP_SOURCE_AUDIO,
            start=EXISTING_VIDEO,
        )

        loadimage = LoadImage(image='')
        loadimage_2 = LoadImage(image='')

        resolutionselector = ResolutionSelector(
            aspect_ratio='16:9 (Widescreen)',
            megapixels=0.5,
            multiple=32,
        )

        loadaudio = LoadAudio(audio='', _mode=4)
        loadaudio_2 = LoadAudio(audio='', _mode=4)

        randomnoise = RandomNoise(
            noise_seed=DEFAULT_SEED_8,
            control_after_generate=FIXED,
            _mode=4,
        )

        minimaxh3avstartmodeparam = raw_call('MiniMaxH3AVStartModeParam',
            _outputs=('start_mode',),
            start=EXISTING_VIDEO,
        )

        minimaxh3avsourceaudiomodeparam = raw_call('MiniMaxH3AVSourceAudioModeParam',
            _outputs=('source_audio_mode',),
            source_audio=KEEP_SOURCE_AUDIO,
        )

        modelattentionbackend = raw_call('ModelAttentionBackend',
            _outputs=('MODEL',),
            attention='comfy kitchen attention',
            model=unetloader.out('MODEL'),
        )

        previewany = PreviewAny(source=comfymathexpression.out('INT'))

        minimaxh3validate24fpsvideo = raw_call('MiniMaxH3Validate24FPSVideo',
            _outputs=('images',),
            images=vhs_loadvideoffmpeg.out('IMAGE'),
            video_info=vhs_loadvideoffmpeg.out('VIDEO_INFO'),
        )

        minimaxh3audiovaecompatibility = raw_call('MiniMaxH3AudioVAECompatibility',
            _outputs=('audio_vae',),
            audio_vae=vaeloader_2.out('VAE'),
        )

        minimaxh3cropto32 = raw_call('MiniMaxH3CropTo32',
            _outputs=('images', 'width', 'height'),
            images=minimaxh3validate24fpsvideo.out('images'),
        )

        loraloadermodelonly = LoraLoaderModelOnly(
            lora_name=LORA_NAME,
            strength_model=GUIDE_STRENGTH,
            model=modelattentionbackend.out('MODEL'),
        )

        minimaxh3sigmashift = raw_call('MiniMaxH3SigmaShift',
            _outputs=('MODEL',),
            shift_audio=3,
            shift_video=12,
            model=loraloadermodelonly.out('MODEL'),
        )

        minimaxh3startcanvasselector = raw_call('MiniMaxH3StartCanvasSelector',
            _outputs=('width', 'height'),
            generated_height=resolutionselector.out('HEIGHT'),
            generated_width=resolutionselector.out('WIDTH'),
            source_height=minimaxh3cropto32.out('height'),
            source_width=minimaxh3cropto32.out('width'),
            start_mode=minimaxh3avstartmodeparam.out('start_mode'),
        )

        minimaxh3sourceaudioregenlength = raw_call('MiniMaxH3SourceAudioRegenLength',
            _outputs=('h3_length', 'source_frames_24fps'),
            source_fps=24,
            source_frames=minimaxh3cropto32.out('images'),
            _mode=4,
        )

        minimaxh3referencetovideo_2 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
        )

        minimaxh3referencetovideo_3 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
            _mode=4,
        )

        minimaxh3referencetovideo_4 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
            _mode=4,
        )

        minimaxh3referencetovideo_5 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
            _mode=4,
        )

        minimaxh3referencetovideo_6 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
            _mode=4,
        )

        minimaxh3referencetovideo_7 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
            _mode=4,
        )

        minimaxh3referencetovideo_8 = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT_2,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3startcanvasselector.out('height'),
            length=comfymathexpression.out('INT'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3startcanvasselector.out('width'),
            _mode=4,
        )

        basicscheduler = BasicScheduler(
            scheduler='simple',
            steps=8,
            denoise=1,
            model=minimaxh3sigmashift.out('MODEL'),
        )

        minimaxh3referencetovideo = raw_call('MiniMaxH3ReferenceToVideo',
            _outputs=('positive', 'LATENT'),
            prompt=DEFAULT_PROMPT_3,
            ref_image_size=MATCH,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            clip=cliploader.out('CLIP'),
            height=minimaxh3cropto32.out('height'),
            length=minimaxh3sourceaudioregenlength.out('h3_length'),
            vae=vaeloader.out('VAE'),
            width=minimaxh3cropto32.out('width'),
            _mode=4,
        )

        basicguider_2 = BasicGuider(
            conditioning=minimaxh3referencetovideo_2.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
        )

        basicguider_3 = BasicGuider(
            conditioning=minimaxh3referencetovideo_3.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        basicguider_4 = BasicGuider(
            conditioning=minimaxh3referencetovideo_4.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        basicguider_5 = BasicGuider(
            conditioning=minimaxh3referencetovideo_5.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        basicguider_6 = BasicGuider(
            conditioning=minimaxh3referencetovideo_6.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        basicguider_7 = BasicGuider(
            conditioning=minimaxh3referencetovideo_7.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        minimaxh3customkeyframes = raw_call('MiniMaxH3CustomKeyframes',
            _outputs=('conditioning',),
            crop=DISABLED,
            indexing='1-based',
            keyframe_state='{"count":1,"positions":[1]}',
            conditioning=minimaxh3referencetovideo_8.out('positive'),
            keyframe_image_1=loadimage_3.out('IMAGE'),
            latent=minimaxh3referencetovideo_8.out('LATENT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        minimaxh3sourceaudioregenmask = raw_call('MiniMaxH3SourceAudioRegenMask',
            _outputs=('latent',),
            crop=DISABLED,
            source_fps=24,
            latent=minimaxh3referencetovideo.out('LATENT'),
            source_frames=minimaxh3cropto32.out('images'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        basicguider = BasicGuider(
            conditioning=minimaxh3referencetovideo.out('positive'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        basicguider_8 = BasicGuider(
            conditioning=minimaxh3customkeyframes.out('conditioning'),
            model=minimaxh3sigmashift.out('MODEL'),
            _mode=4,
        )

        samplercustomadvanced = SamplerCustomAdvanced(
            guider=basicguider.out('GUIDER'),
            latent_image=minimaxh3sourceaudioregenmask.out('latent'),
            noise=randomnoise.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        samplercustomadvanced_8 = SamplerCustomAdvanced(
            guider=basicguider_8.out('GUIDER'),
            latent_image=minimaxh3referencetovideo_8.out('LATENT'),
            noise=randomnoise_8.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        minimaxh3sourceaudiopolicy = raw_call('MiniMaxH3SourceAudioPolicy',
            _outputs=('source_audio',),
            source_fps=24,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            mode=minimaxh3avsourceaudiomodeparam.out('source_audio_mode'),
            regenerated_latent=samplercustomadvanced.out('OUTPUT'),
            source_frames=minimaxh3cropto32.out('images'),
            video_info=vhs_loadvideoffmpeg.out('VIDEO_INFO'),
        )

        minimaxh3startmaskedcontext = raw_call('MiniMaxH3StartMaskedContext',
            _outputs=('latent', 'trim_frames'),
            audio_feather_ticks=8,
            context_length=39,
            crop=DISABLED,
            source_fps=24,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            latent=minimaxh3referencetovideo_2.out('LATENT'),
            live_starter_latent=samplercustomadvanced_8.out('OUTPUT'),
            source_audio=minimaxh3sourceaudiopolicy.out('source_audio'),
            source_frames=minimaxh3cropto32.out('images'),
            start_mode=minimaxh3avstartmodeparam.out('start_mode'),
            vae=vaeloader.out('VAE'),
        )

        # Decode
        vaedecode_3 = VAEDecode(
            samples=samplercustomadvanced_8.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        vaedecodeaudio_4 = VAEDecodeAudio(
            samples=samplercustomadvanced_8.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            _mode=4,
        )

        samplercustomadvanced_2 = SamplerCustomAdvanced(
            guider=basicguider_2.out('GUIDER'),
            latent_image=minimaxh3startmaskedcontext.out('latent'),
            noise=randomnoise_2.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
        )

        # Outputs
        vhs_videocombine_4 = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/generated_starter',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio_4.out('AUDIO'),
            images=vaedecode_3.out('IMAGE'),
            _mode=4,
        )

        minimaxh3generatedavmaskedcontext = raw_call('MiniMaxH3GeneratedAVMaskedContext',
            _outputs=('latent', 'trim_frames'),
            audio_feather_ticks=8,
            context_length=39,
            latent=minimaxh3referencetovideo_3.out('LATENT'),
            source_latent=samplercustomadvanced_2.out('OUTPUT'),
            _mode=4,
        )

        vaedecode_4 = VAEDecode(
            samples=samplercustomadvanced_2.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
        )

        vaedecodeaudio_5 = VAEDecodeAudio(
            samples=samplercustomadvanced_2.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
        )

        samplercustomadvanced_3 = SamplerCustomAdvanced(
            guider=basicguider_3.out('GUIDER'),
            latent_image=minimaxh3generatedavmaskedcontext.out('latent'),
            noise=randomnoise_3.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        vhs_videocombine_5 = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/extension_01',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio_5.out('AUDIO'),
            images=vaedecode_4.out('IMAGE'),
        )

        minimaxh3generatedavmaskedcontext_2 = raw_call('MiniMaxH3GeneratedAVMaskedContext',
            _outputs=('latent', 'trim_frames'),
            audio_feather_ticks=8,
            context_length=39,
            latent=minimaxh3referencetovideo_4.out('LATENT'),
            source_latent=samplercustomadvanced_3.out('OUTPUT'),
            _mode=4,
        )

        vaedecode_5 = VAEDecode(
            samples=samplercustomadvanced_3.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        vaedecodeaudio_6 = VAEDecodeAudio(
            samples=samplercustomadvanced_3.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            _mode=4,
        )

        samplercustomadvanced_4 = SamplerCustomAdvanced(
            guider=basicguider_4.out('GUIDER'),
            latent_image=minimaxh3generatedavmaskedcontext_2.out('latent'),
            noise=randomnoise_4.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        vhs_videocombine_6 = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/extension_02',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio_6.out('AUDIO'),
            images=vaedecode_5.out('IMAGE'),
            _mode=4,
        )

        minimaxh3generatedavmaskedcontext_3 = raw_call('MiniMaxH3GeneratedAVMaskedContext',
            _outputs=('latent', 'trim_frames'),
            audio_feather_ticks=8,
            context_length=39,
            latent=minimaxh3referencetovideo_5.out('LATENT'),
            source_latent=samplercustomadvanced_4.out('OUTPUT'),
            _mode=4,
        )

        vaedecode_6 = VAEDecode(
            samples=samplercustomadvanced_4.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        vaedecodeaudio_7 = VAEDecodeAudio(
            samples=samplercustomadvanced_4.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            _mode=4,
        )

        samplercustomadvanced_5 = SamplerCustomAdvanced(
            guider=basicguider_5.out('GUIDER'),
            latent_image=minimaxh3generatedavmaskedcontext_3.out('latent'),
            noise=randomnoise_5.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        vhs_videocombine_7 = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/extension_03',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio_7.out('AUDIO'),
            images=vaedecode_6.out('IMAGE'),
            _mode=4,
        )

        minimaxh3generatedavmaskedcontext_4 = raw_call('MiniMaxH3GeneratedAVMaskedContext',
            _outputs=('latent', 'trim_frames'),
            audio_feather_ticks=8,
            context_length=39,
            latent=minimaxh3referencetovideo_6.out('LATENT'),
            source_latent=samplercustomadvanced_5.out('OUTPUT'),
            _mode=4,
        )

        vaedecode_7 = VAEDecode(
            samples=samplercustomadvanced_5.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        vaedecodeaudio = VAEDecodeAudio(
            samples=samplercustomadvanced_5.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            _mode=4,
        )

        samplercustomadvanced_6 = SamplerCustomAdvanced(
            guider=basicguider_6.out('GUIDER'),
            latent_image=minimaxh3generatedavmaskedcontext_4.out('latent'),
            noise=randomnoise_6.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        vhs_videocombine = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/extension_04',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio.out('AUDIO'),
            images=vaedecode_7.out('IMAGE'),
            _mode=4,
        )

        minimaxh3generatedavmaskedcontext_5 = raw_call('MiniMaxH3GeneratedAVMaskedContext',
            _outputs=('latent', 'trim_frames'),
            audio_feather_ticks=8,
            context_length=39,
            latent=minimaxh3referencetovideo_7.out('LATENT'),
            source_latent=samplercustomadvanced_6.out('OUTPUT'),
            _mode=4,
        )

        vaedecode = VAEDecode(
            samples=samplercustomadvanced_6.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        vaedecodeaudio_2 = VAEDecodeAudio(
            samples=samplercustomadvanced_6.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            _mode=4,
        )

        samplercustomadvanced_7 = SamplerCustomAdvanced(
            guider=basicguider_7.out('GUIDER'),
            latent_image=minimaxh3generatedavmaskedcontext_5.out('latent'),
            noise=randomnoise_7.out('NOISE'),
            sampler=ksamplerselect.out('SAMPLER'),
            sigmas=basicscheduler.out('SIGMAS'),
            _mode=4,
        )

        vhs_videocombine_2 = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/extension_05',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio_2.out('AUDIO'),
            images=vaedecode.out('IMAGE'),
            _mode=4,
        )

        vaedecode_2 = VAEDecode(
            samples=samplercustomadvanced_7.out('OUTPUT'),
            vae=vaeloader.out('VAE'),
            _mode=4,
        )

        vaedecodeaudio_3 = VAEDecodeAudio(
            samples=samplercustomadvanced_7.out('OUTPUT'),
            vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            _mode=4,
        )

        vhs_videocombine_3 = VHS_VideoCombine(
            frame_rate=24,
            loop_count=0,
            filename_prefix='h3_preview/extension_06',
            format=VIDEO_H264_MP4,
            pingpong=False,
            save_output=False,
            crf=19,
            pix_fmt=YUV420P,
            save_metadata=False,
            trim_to_audio=True,
            audio=vaedecodeaudio_3.out('AUDIO'),
            images=vaedecode_2.out('IMAGE'),
            _mode=4,
        )

        minimaxh3lastactivevhspreviewbarrier = raw_call('MiniMaxH3LastActiveVHSPreviewBarrier',
            _outputs=('preview_gate',),
            active_extensions=1,
            input_count=6,
            preview_1=vhs_videocombine_5.out('FILENAMES'),
            preview_2=vhs_videocombine_6.out('FILENAMES'),
            preview_3=vhs_videocombine_7.out('FILENAMES'),
            preview_4=vhs_videocombine.out('FILENAMES'),
            preview_5=vhs_videocombine_2.out('FILENAMES'),
            preview_6=vhs_videocombine_3.out('FILENAMES'),
        )

        minimaxh3streamliveextensionavtovhs = raw_call('MiniMaxH3StreamLiveExtensionAVToVHS',
            _outputs=('Filenames',),
            active_extensions=1,
            context_frames=39,
            crf=19,
            crop=DISABLED,
            filename_prefix='video/masked_av_extension',
            input_count=6,
            pix_fmt=YUV420P,
            save_metadata=False,
            save_output=True,
            source_fps=24,
            # The H3 frame timeline is authoritative.  VideoHelperSuite's
            # trim_to_audio=True path muxes with -shortest; AAC priming can
            # then drop the final video frame even though the stream emitted
            # the exact compiled frame count.  Keep the video count exact and
            # let VHS pad audio to that timeline instead.
            trim_to_audio=False,
            video_overlap_frames=39,
            audio_vae=minimaxh3audiovaecompatibility.out('audio_vae'),
            extension_1=samplercustomadvanced_2.out('OUTPUT'),
            extension_2=samplercustomadvanced_3.out('OUTPUT'),
            extension_3=samplercustomadvanced_4.out('OUTPUT'),
            extension_4=samplercustomadvanced_5.out('OUTPUT'),
            extension_5=samplercustomadvanced_6.out('OUTPUT'),
            extension_6=samplercustomadvanced_7.out('OUTPUT'),
            preview_gate=minimaxh3lastactivevhspreviewbarrier.out('preview_gate'),
            source_audio=minimaxh3sourceaudiopolicy.out('source_audio'),
            source_frames=minimaxh3cropto32.out('images'),
            start_mode=minimaxh3avstartmodeparam.out('start_mode'),
            starter_latent=samplercustomadvanced_8.out('OUTPUT'),
            video_vae=vaeloader.out('VAE'),
        )

        minimaxh3finalizevhsoutput = raw_call('MiniMaxH3FinalizeVHSOutput',
            filenames=minimaxh3streamliveextensionavtovhs.out('Filenames'),
        )

        wf = wf.finalize(PUBLIC_INPUT_METADATA, outputs=[OutputSpec(node=minimaxh3streamliveextensionavtovhs, output_type='MiniMaxH3StreamLiveExtensionAVToVHS', name='continuation', artifact_kind='video', mime_type='video/mp4', filename_prefix='video/masked_av_extension', expected_cardinality='one')])
        wf.strict_types = False
        wf.nodes['99'].inputs.update({
            'video': source_video,
            'start_time': source_start,
            'frame_load_cap': source_frames,
        })
        wf.nodes['102'].inputs['values.a'] = duration
        for node in wf.nodes.values():
            if node.class_type == 'MiniMaxH3ReferenceToVideo' and 'prompt' in node.inputs:
                node.inputs['prompt'] = prompt
        wf.nodes['1'].inputs['unet_name'] = model
        wf.nodes['976'].inputs['steps'] = steps
        wf.nodes['120'].inputs['noise_seed'] = seed
        for name, node_id, field, value, media_semantics in (
            ('source_video', '99', 'video', source_video, 'video'),
            ('source_start', '99', 'start_time', source_start, None),
            ('source_frames', '99', 'frame_load_cap', source_frames, None),
            ('duration', '102', 'values.a', duration, None),
            ('prompt', '110', 'prompt', prompt, None),
            ('model', '1', 'unet_name', model, None),
            ('steps', '976', 'steps', steps, None),
            ('seed', '120', 'noise_seed', seed, None),
        ):
            wf.register_input(
                name, node_id, field, value=value, type=None, default=value,
                required=False, range=None, aliases=(), media_semantics=media_semantics,
            )
        return wf
